package com.newbrowser.pro.utils.other

data class GridItem(val icon: Int, val title: String, val data: Int)
