package com.newbrowser.pro.utils.other

import android.util.Base64
import android.webkit.MimeTypeMap

class DataURIParser(url: String) {
    val filename: String
    val imagedata: ByteArray

    init {
        //Log.d("DataURIParse", url);
        val data = url.substring(url.indexOf(",") + 1)
        //Log.d("DataURIParse", data);
        val mimeType = url.substring(url.indexOf(":") + 1, url.indexOf(";"))
        //Log.d("DataURIParse", mimeType);
        val fileType = url.substring(url.indexOf(":") + 1, url.indexOf("/"))
        //Log.d("DataURIParse", fileType);
        val suffix = MimeTypeMap.getSingleton().getExtensionFromMimeType(mimeType)
        //Log.d("DataURIParse", suffix);
        filename = "$fileType.$suffix"
        //Log.d("DataURIParse", filename);
        imagedata = Base64.decode(data, Base64.DEFAULT)
    }
}
