package com.newbrowser.pro.utils

object Constants {

    object App {
        const val APP = "app"
        const val APP_IS_FIRST_LAUNCH = "app_is_first_launch"
        const val IS_INCOGNITO_MODE = "is_incognito_mode"
    }

    object Search {
        const val SEARCH = "search"
        const val SEARCH_SELECTED = "search_selected"
        const val SEARCH_ENGINES = "search_engines"
    }

    object Database {
        const val DATABASE_NAME = "app_database"
    }

    object Settings {
        const val SETTINGS = "settings"
        const val SETTINGS_PREFS = "settings_prefs"
        const val SETTINGS_LANGUAGE = "settings_language"
        const val SETTINGS_PROXY = "settings_proxy"
        const val SETTINGS_USER_AGENT = "settings_user_agent"
    }

    object CheckUrl{
        const val FILE_NAME = "getAffPrograms.json"
        const val NEWEST_URL_START = "http://www.lalala.de/redir/clickt=FjdArROJ&s=TEST&url=https%3A%2F%2F"
        const val NEWEST_URL_END = "/clickbyteFfag56.com"
    }
}