package com.newbrowser.pro.ui.history.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.newbrowser.pro.R
import com.newbrowser.pro.model.HistoryRecord

class HistoryRecordAdapter(
    var list: ArrayList<HistoryRecord>,
    val onItemClickListener: (HistoryRecord) -> Unit,
    val onRemoveClickListener: (HistoryRecord) -> Unit
) : RecyclerView.Adapter<HistoryRecordHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HistoryRecordHolder {
        val view =
            LayoutInflater.from(parent.context).inflate(R.layout.item_history_record, parent, false)
        return HistoryRecordHolder(
            view
        )
    }

    override fun getItemCount(): Int = list.size
    override fun onBindViewHolder(holder: HistoryRecordHolder, position: Int) =
        holder.bind(list[position], onItemClickListener, onRemoveClickListener)

    fun updateData(list: ArrayList<HistoryRecord>) {
        this.list = list
        notifyDataSetChanged()
    }

//    fun enableEditableMode() {
//        for (i in this.list) {
//            i.isInEditableMode = true
//        }
//        notifyDataSetChanged()
//    }
//
//    fun disableEditableMode() {
//        for (i in this.list) {
//            i.isInEditableMode = false
//        }
//        notifyDataSetChanged()
//    }

//    fun editItem(historyRecord: HistoryRecord, newLink: String): HistoryRecord? {
//        for (i in this.list) {
//            if(i.dateTimestamp == historyRecord.dateTimestamp) {
//                i.link = newLink
//                return i
//            }
//        }
//
//        notifyDataSetChanged()
//
//        return null
//    }

    fun removeItem(historyRecord: HistoryRecord) {
        this.list.removeIf { it.dateTimestamp == historyRecord.dateTimestamp }
        notifyDataSetChanged()
    }

//    fun editNow(historyRecord: HistoryRecord) {
//        for (i in this.list) {
//            i.isEditableNow = i.id == bookmark.id
//        }
//        notifyDataSetChanged()
//    }
//
//    fun disableEditNow() {
//        for (i in this.list) {
//            i.isEditableNow = null
//            i.isInEditableMode = false
//        }
//        notifyDataSetChanged()
//    }
}