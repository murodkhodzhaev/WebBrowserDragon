package com.newbrowser.pro.ui.home.bookmarks

import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.newbrowser.pro.R
import com.newbrowser.pro.model.Bookmark

class BookmarksAdapter(
    var list: ArrayList<Bookmark>,
    val onItemClickListener: (Bookmark) -> Unit,
    val onEditClickListener: (Bookmark) -> Unit,
    val onRemoveClickListener: (Bookmark) -> Unit
) : RecyclerView.Adapter<BookmarksHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BookmarksHolder {
        val view =
            LayoutInflater.from(parent.context).inflate(R.layout.item_bookmark, parent, false)
        return BookmarksHolder(
            view
        )
    }

    override fun getItemCount(): Int = list.size
    override fun onBindViewHolder(holder: BookmarksHolder, position: Int) =
        holder.bind(list[position], onItemClickListener, onEditClickListener, onRemoveClickListener)

    fun updateData(list: ArrayList<Bookmark>) {
        this.list = list
        Log.d("closeEditingDialog()11", "closeEditingDialog()")
        notifyDataSetChanged()
        //enableEditableMode()
    }

    fun enableEditableMode() {
        Log.d("closeEditingDialog()12", "closeEditingDialog()")
        for (i in this.list) {
            i.isInEditableMode = true
        }
        notifyDataSetChanged()
    }

    fun disableEditableMode() {
        Log.d("closeEditingDialog()13", "closeEditingDialog()")
        for (i in this.list) {
            i.isInEditableMode = false
        }
        notifyDataSetChanged()
    }

    fun editItem(bookmark: Bookmark, newLink: String): Bookmark? {
        Log.d("closeEditingDialog()14", "closeEditingDialog()")
        for (i in this.list) {
            if(i.id == bookmark.id) {
                i.link = newLink
                return i
            }
        }

        notifyDataSetChanged()

        return null
    }

    fun removeItem(bookmark: Bookmark) {
        Log.d("closeEditingDialog()15", "closeEditingDialog()")
        this.list.removeIf { it.id == bookmark.id}
        notifyDataSetChanged()
    }

    fun editNow(bookmark: Bookmark) {
        Log.d("closeEditingDialog()16", "closeEditingDialog()")
        for (i in this.list) {
            i.isEditableNow = i.id == bookmark.id
        }
        notifyDataSetChanged()
    }

    fun disableEditNow() {
        Log.d("closeEditingDialog()10", "closeEditingDialog()")
        for (i in this.list) {
            i.isEditableNow = null
            i.isInEditableMode = false
        }
        notifyDataSetChanged()
    }
}