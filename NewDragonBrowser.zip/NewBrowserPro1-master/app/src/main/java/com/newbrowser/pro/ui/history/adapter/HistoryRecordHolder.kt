package com.newbrowser.pro.ui.history.adapter

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.newbrowser.pro.model.HistoryRecord
import com.newbrowser.pro.utils.loadImage
import kotlinx.android.synthetic.main.item_history_record.view.*

class HistoryRecordHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    fun bind(
        data: HistoryRecord,
        onItemClickListener: (HistoryRecord) -> Unit,
        onRemoveClickListener: (HistoryRecord) -> Unit
    ) {
        itemView.setOnClickListener { onItemClickListener(data) }
        itemView.iv_remove?.setOnClickListener { onRemoveClickListener(data) }

        itemView.tv_history_record?.text = data.link

        loadImage(itemView.context, itemView.iv_favicon, null,
        "https://t1.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=${data.link}&size=64")
    }
}