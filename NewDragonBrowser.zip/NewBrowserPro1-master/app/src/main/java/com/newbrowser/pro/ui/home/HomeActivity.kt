package com.newbrowser.pro.ui.home

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.URLUtil
import android.widget.PopupMenu
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.core.content.edit
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.newbrowser.pro.NewBrowserPro
import com.newbrowser.pro.R
import com.newbrowser.pro.database.bookmarks.BookmarksViewModel
import com.newbrowser.pro.database.bookmarks.BookmarksViewModelFactory
import com.newbrowser.pro.model.Bookmark
import com.newbrowser.pro.model.SearchEngine
import com.newbrowser.pro.ui.browser.BrowserActivity
import com.newbrowser.pro.ui.downloads.DownloadsActivity
import com.newbrowser.pro.ui.history.HistoryRecordsActivity
import com.newbrowser.pro.ui.home.bookmarks.BookmarksAdapter
import com.newbrowser.pro.ui.home.search.adapter.SearchEngineAdapter
import com.newbrowser.pro.ui.settings.SettingsActivity
import com.newbrowser.pro.ui.tabs.TabsActivity
import com.newbrowser.pro.utils.*
import kotlinx.android.synthetic.main.activity_browser3.*
import kotlinx.android.synthetic.main.activity_home.*
import kotlinx.android.synthetic.main.activity_home.b_tabs
import kotlinx.android.synthetic.main.activity_home.et_search_field
import kotlinx.android.synthetic.main.activity_home.ib_search_menu
import kotlinx.android.synthetic.main.activity_home.iv_search
import kotlinx.android.synthetic.main.activity_home.rv_search_engines
import kotlinx.android.synthetic.main.activity_tabs.*
import timber.log.Timber
import java.util.*
import kotlin.collections.ArrayList

class HomeActivity : AppCompatActivity() {

    companion object {
        fun newIntent(context: Context) = Intent(context, HomeActivity::class.java)
    }

    private val bookmarksViewModel: BookmarksViewModel by viewModels {
        BookmarksViewModelFactory((this.application as NewBrowserPro).bookmarksRepository)
    }

    private var searchEngineAdapter: SearchEngineAdapter? = null
    private var bookmarksAdapter: BookmarksAdapter? = null
    private var bookmarksPopularAdapter: BookmarksAdapter? = null
    private var isEditingListOpened = false
    private var isEditingElementOpened = false

    private val nameTabs = "tabs"
    private val nameTabsOfIncognito = "tabs_incognito"

    private var currentTabs = mutableListOf<String>()

    private var currentLanguage: String? = null

    private var isShowEditDialog = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        startSettingsOfHome()
        setOnClickListeners()
        initRecyclers()
        setData()
        setOnActionListeners()
        incognitoMode()
    }

    private fun incognitoMode() {
        if (isIncognitoMode(this)) {
            onIncognitoMode()
        } else {
            offIncognitoMode()
        }
    }

    private fun onIncognitoMode() {
        b_tabs.isSelected = true
        //close.isActivated = true
        //rl_incognito.isActivated = true
        //iv_incognito.setColorFilter(ContextCompat.getColor(this, R.color.incognito_dark))
//        cl_buttons_tabs.setBackgroundColor(ContextCompat.getColor(this, R.color.incognito_dark))
//        iv_add_tabs.setImageResource(R.drawable.ic_add_tab_incognito)
        content.setBackgroundColor(ContextCompat.getColor(this, R.color.incognito_dark))
        nsv_content.visibility = View.GONE
        incognito_mode_home.visibility = View.VISIBLE
        //tab_switcher.setBackgroundColor(ContextCompat.getColor(this, R.color.incognito_dark))
    }

    private fun offIncognitoMode() {
        b_tabs.isSelected = false
        content.setBackgroundColor(ContextCompat.getColor(this, R.color.white))
        nsv_content.visibility = View.VISIBLE
        incognito_mode_home.visibility = View.GONE
//        iv_incognito.setColorFilter(ContextCompat.getColor(this, R.color.grey_2))
//        cl_buttons_tabs.setBackgroundColor(ContextCompat.getColor(this, R.color.white))
//        iv_add_tabs.setImageResource(R.drawable.ic_add_tab)
//        cl_main_tabs.setBackgroundColor(ContextCompat.getColor(this, R.color.white))
//        tab_switcher.setBackgroundColor(ContextCompat.getColor(this, R.color.white))
    }

    private fun startSettingsOfHome(){
        currentLanguage = getSharedPreferences(Constants.Settings.SETTINGS_LANGUAGE, Context.MODE_PRIVATE).getString(
            Constants.Settings.SETTINGS_LANGUAGE, "en")

        for(item in getSharedPreferences(if(!isIncognitoMode(this)) nameTabs else nameTabsOfIncognito, Context.MODE_PRIVATE).all){
            currentTabs.add(item.toString())
        }
        b_tabs.text = currentTabs.size.toString()
    }

    override fun onBackPressed() {
        if (isEditingListOpened) {
            closeEditFirstDialog()
        } else if (isEditingElementOpened) {
            Log.d("closeEditingDialog()5", "closeEditingDialog()")
            closeEditingDialog()
        } else {
            super.onBackPressed()
        }
    }

    private fun observeBookmarks() {
        bookmarksViewModel.simpleBookmarks.observe(this, androidx.lifecycle.Observer {
            it?.let {
                Timber.d("TAG_LIST_2: ${it}")
                bookmarksAdapter?.updateData(ArrayList(it))
                if(isShowEditDialog) showEditDialog()
            }
        })
    }

    private fun observeBookmarksPopular() {
        bookmarksViewModel.popularBookmarks.observe(this, androidx.lifecycle.Observer {
            it?.let {
                Timber.d("TAG_LIST_3: ${it}")
                if(!it.isNullOrEmpty()) {
                    bookmarksPopularAdapter?.updateData(ArrayList(it))
                }
                else {
                    bookmarksViewModel.insertAll(getBookmarks())
                }
            }
        })
    }

    private fun showMenu() {
        val menu =
            PopupMenu(
                this,
                ib_search_menu
            )
        menu.inflate(R.menu.home_menu)
        menu.setOnMenuItemClickListener {
            when (it.itemId) {
                R.id.item_edit_tabs -> {
                    showEditDialog()
                    isShowEditDialog = true
                }
                R.id.item_edit_tabs_finish -> {
                    bookmarksAdapter?.disableEditableMode()
                    cl_select_bookmark_for_editing?.visibility = View.GONE
                    cl_edit_bookmark?.visibility = View.GONE
                    Log.d("closeEditingDialog()6", "closeEditingDialog()")
                    closeEditingDialog()
                    isShowEditDialog = false
                }
                R.id.item_settings -> {
                    startActivity(SettingsActivity.newIntent(this))
                }
                R.id.item_history -> {
                    startActivity(HistoryRecordsActivity.newIntent(this))
                }
                R.id.item_downloads -> {
                    startActivity(DownloadsActivity.newIntent(this))
                }
            }
            false
        }

        menu.show()
    }

    private fun closeEditingDialog() {
        Log.d("closeEditingDialog()9", "closeEditingDialog()")
        //Log.d("closeEditingDialog()1", "closeEditingDialog()")
        cl_edit_bookmark?.visibility = View.GONE
        bookmarksAdapter?.disableEditNow()
        bookmarksAdapter?.disableEditableMode()
        isEditingElementOpened = false
        isEditingListOpened = false
    }

    private fun showEditDialog() {
        bookmarksAdapter?.enableEditableMode()
        cl_select_bookmark_for_editing?.visibility = View.VISIBLE
        isEditingListOpened = true

        b_cancel?.setOnClickListener {
            closeEditFirstDialog()
        }
    }

    private fun closeEditFirstDialog() {
        Log.d("closeEditingDialog()8", "closeEditingDialog()")
        bookmarksAdapter?.disableEditableMode()
        isEditingListOpened = false
        cl_select_bookmark_for_editing?.visibility = View.GONE
    }

    private fun showBookmarkEditDialog(bookmark: Bookmark) {
        isEditingElementOpened = true
        cl_select_bookmark_for_editing?.visibility = View.GONE
        cl_edit_bookmark?.visibility = View.VISIBLE

        bookmarksAdapter?.editNow(bookmark)

        if (!bookmark.link.isNullOrEmpty()) {
            et_link_field?.setText(bookmark.link)
        }

        iv_remove_text?.setOnClickListener {
            et_link_field?.text?.clear()
        }

        b_save_editing?.setOnClickListener {
            if (!et_link_field?.text?.toString().isNullOrEmpty()) {
                val bookmarkEdited =
                    bookmarksAdapter?.editItem(bookmark, et_link_field?.text?.toString()!!)
                if (bookmarkEdited != null) {
                    bookmarksViewModel?.update(
                        bookmarkEdited.copy(
                            isInEditableMode = false,
                            isEditableNow = null
                        )
                    ).observe(this, Observer {
                        it?.let {
                            Toast.makeText(
                                this,
                                getString(R.string.home_edit_bookmark_saved),
                                Toast.LENGTH_SHORT
                            ).show()
                            Log.d("closeEditingDialog()2", "closeEditingDialog()")
                            closeEditingDialog()
                        }
                    })
                } else {
                    Toast.makeText(
                        this,
                        getString(R.string.error),
                        Toast.LENGTH_SHORT
                    ).show()
                    Log.d("closeEditingDialog()3", "closeEditingDialog()")
                    closeEditingDialog()
                }
            } else {
                Toast.makeText(
                    this,
                    getString(R.string.home_edit_bookmark_empty),
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        b_cancel_editing?.setOnClickListener {
            Log.d("closeEditingDialog()4", "closeEditingDialog()")
            closeEditingDialog()
        }
    }

    private fun setData() {
        validatePermissions()
        setSearchEngine()
    }

    private fun setSearchEngine() {
        val searchEngine = getSelectedSearchEngine(this)

        if (searchEngine != null) {
            saveSelectedSearchEngine(this, searchEngine)
            searchEngineAdapter?.selectItem(searchEngine)
        } else {
            val googleSearchEngine = getSearchEngines(this)[0]
            saveSelectedSearchEngine(this, googleSearchEngine)
            searchEngineAdapter?.selectItem(googleSearchEngine)
        }
    }

    private fun setOnClickListeners() {
        ib_search_menu?.setOnClickListener {
            showMenu()
        }
        iv_search?.setOnClickListener {
            onSearchClicked()
        }
        b_tabs?.setOnClickListener {
            if(b_tabs.text != "0") startActivity(TabsActivity.newIntent(this))
        }
    }

    private fun setOnActionListeners() {
        et_search_field?.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
//                hideKeyboard(settingsView?.findViewById<EditText>(R.id.et_time_value_2))
                onSearchClicked()
                return@setOnEditorActionListener true
            }
            false
        }
    }

    private fun onSearchClicked() {
        val searchText = et_search_field?.text?.toString()

        if (!searchText.isNullOrEmpty()) {
            startActivity(BrowserActivity.newIntent(this, searchText))
        } else {
            Toast.makeText(this, getString(R.string.search_empty_error), Toast.LENGTH_SHORT).show()
        }
    }

    private fun initRecyclers() {
        searchEngineAdapter = SearchEngineAdapter(arrayListOf()) {
            onSearchEngineClicked(it)
        }
        rv_search_engines?.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        rv_search_engines?.adapter = searchEngineAdapter

        searchEngineAdapter?.updateData(getSearchEngines(this))

        bookmarksAdapter = BookmarksAdapter(arrayListOf(), {
            onBookmarkClicked(it)
        }, {
            onBookmarkEditClicked(it)
        }, {
            onBookmarkDeleteClicked(it)
        })
        rv_bookmarks?.layoutManager = GridLayoutManager(this, 2)
        rv_bookmarks?.adapter = bookmarksAdapter

//        bookmarksAdapter?.updateData(getBookmarks())

        bookmarksPopularAdapter = BookmarksAdapter(arrayListOf(), {
            onPopularBookmarkClicked(it)
        }, {}, {})
        rv_popular?.layoutManager = GridLayoutManager(this, 2)
        rv_popular?.adapter = bookmarksPopularAdapter

        observeBookmarks()
        observeBookmarksPopular()
    }

    private fun onSearchEngineClicked(searchEngine: SearchEngine) {
        saveSelectedSearchEngine(this, searchEngine)
        searchEngineAdapter?.selectItem(searchEngine)
    }

    private fun onBookmarkClicked(bookmark: Bookmark) {
//        val myIntent = Intent(this, TestActivity::class.java)
//        startActivity(myIntent)
//        startActivity(MainActivity.newIntent(this, bookmark.link))
        Timber.d("TAG_LIST_1: ${bookmark}")

        currentTabs.add(bookmark.link)
//        getSharedPreferences(nameTabs, Context.MODE_PRIVATE).edit {
//            this.putString(currentTabs.size.toString(), bookmark.link)
//        }
//        b_tabs.text = currentTabs.size.toString()
        startActivity(BrowserActivity.newIntent(this, bookmark.link))
    }

    private fun onBookmarkEditClicked(bookmark: Bookmark) {
        showBookmarkEditDialog(bookmark)
    }

    private fun onBookmarkDeleteClicked(bookmark: Bookmark) {
        bookmarksViewModel.delete(bookmark).observe(this, Observer {
            it?.let {
                bookmarksAdapter?.removeItem(bookmark)
            }
        })
//        AlertDialog.Builder(this)
//            .setCancelable(false)
//            .setMessage(getString(R.string.home_delete_bookmark_dialog_message))
//            .setPositiveButton(
//                getString(R.string.yes)
//            ) { dialog, _ ->
//                bookmarksViewModel.delete(bookmark).observe(this, Observer {
//                    it?.let {
//                        bookmarksAdapter?.removeItem(bookmark)
//                        dialog.dismiss()
//                    }
//                })
//            }
//            .setNegativeButton(
//                getString(R.string.no)
//            ) { dialog, _ ->
//                dialog.dismiss()
//            }
//            .show()
    }

    private fun onPopularBookmarkClicked(bookmark: Bookmark) {
        startActivity(BrowserActivity.newIntent(this, bookmark.link))
    }

    private val activityResultLauncher =
        registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { }

    private fun grantPermissions() {

        activityResultLauncher.launch(
            arrayOf(
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.MANAGE_EXTERNAL_STORAGE,
                Manifest.permission.CAMERA
            )
        )
    }

    private fun validatePermissions() {

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        ) {

        } else {
            grantPermissions()
        }
    }

    override fun onResume() {
        super.onResume()

        currentTabs.clear()
        for(item in getSharedPreferences(if(!isIncognitoMode(this)) nameTabs else nameTabsOfIncognito, Context.MODE_PRIVATE).all){
            currentTabs.add(item.toString())
        }
        b_tabs.text = currentTabs.size.toString()

        val newestLanguage = getSharedPreferences(Constants.Settings.SETTINGS_LANGUAGE, Context.MODE_PRIVATE).getString(
            Constants.Settings.SETTINGS_LANGUAGE, "en")
        if(currentLanguage != newestLanguage){
            recreate()
        }

        incognitoMode()
    }

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(applySelectedAppLanguage(base))
    }

    private fun applySelectedAppLanguage(context: Context): Context {
        val newestLanguage = context.getSharedPreferences(Constants.Settings.SETTINGS_LANGUAGE, Context.MODE_PRIVATE).getString(
            Constants.Settings.SETTINGS_LANGUAGE, "en")
        val locale = Locale(newestLanguage)
        val newConfig = Configuration(context.resources.configuration)
        Locale.setDefault(locale)
        newConfig.setLocale(locale)
        return context.createConfigurationContext(newConfig)
    }
}