package com.newbrowser.pro.ui.splash

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.content.edit
import com.newbrowser.pro.R
import com.newbrowser.pro.model.Settings
import com.newbrowser.pro.ui.home.HomeActivity
import com.newbrowser.pro.ui.onboarding.OnboardingActivity
import com.newbrowser.pro.utils.Constants
import com.newbrowser.pro.utils.isFirstLaunch
import com.newbrowser.pro.utils.settings.getSettings
import com.newbrowser.pro.utils.settings.saveSettings
import java.util.*

class SplashActivity : AppCompatActivity() {

    private val nameTabsOfIncognito = "tabs_incognito"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        setSettings()
        chooseNextActivity()
    }

    private fun setSettings() {
        getSharedPreferences(nameTabsOfIncognito, Context.MODE_PRIVATE).edit().clear().apply()
        if(getSettings(this) == null) {
            saveSettings(this, Settings())
        }
    }

    private fun chooseNextActivity() {
        if(isFirstLaunch(this)) {
            val languagesCodeArray: Array<String> = resources.getStringArray(R.array.languages_code)
            var code = Locale.getDefault().language
            if(code in languagesCodeArray){
                code = "en"
            }

            getSharedPreferences(Constants.Settings.SETTINGS_LANGUAGE, Context.MODE_PRIVATE).edit {
                this.putString(Constants.Settings.SETTINGS_LANGUAGE, code)
            }
            startActivity(OnboardingActivity.newIntent(this))
        }
        else {
            startActivity(HomeActivity.newIntent(this))
        }
    }
}