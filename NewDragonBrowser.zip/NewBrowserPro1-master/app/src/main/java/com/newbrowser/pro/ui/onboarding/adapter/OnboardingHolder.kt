package com.newbrowser.pro.ui.onboarding.adapter

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.newbrowser.pro.model.Onboarding
import kotlinx.android.synthetic.main.item_onboarding.view.*

class OnboardingHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    fun bind(onboarding: Onboarding) {
        itemView.tv_onboarding_title.text = onboarding.title
        itemView.tv_onboarding_description.text = onboarding.description
    }
}