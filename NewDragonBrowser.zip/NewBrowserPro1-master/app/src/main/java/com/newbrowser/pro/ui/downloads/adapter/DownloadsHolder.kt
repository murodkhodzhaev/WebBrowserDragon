package com.newbrowser.pro.ui.downloads.adapter

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.newbrowser.pro.R
import com.newbrowser.pro.model.DownloadModel
import kotlinx.android.synthetic.main.item_download.view.*

class DownloadsHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    fun bind(
        data: DownloadModel,
        onItemClickListener: (DownloadModel) -> Unit
    ) {
        itemView.setOnClickListener { onItemClickListener(data) }

        itemView.tv_file_title?.text = data.fileRealName
        itemView.tv_file_size_and_extension?.text = "${data.fileSize}, ${data.extension}"

        when (data.extension) {
            "pdf" -> {
                itemView.iv_file_extension?.setImageResource(R.drawable.ic_pdf_file)
            }
            "xls" -> {
                itemView.iv_file_extension?.setImageResource(R.drawable.ic_xls_file)
            }
            else -> {
                itemView.iv_file_extension?.setImageResource(R.drawable.ic_any_file)
            }
        }
    }
}