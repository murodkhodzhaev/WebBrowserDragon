package com.newbrowser.pro.ui.tabs

import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import androidx.appcompat.app.AppCompatActivity
import de.mrapp.android.util.multithreading.AbstractDataBinder
import java.lang.Void
import android.os.Bundle
import android.view.View
import android.view.LayoutInflater
import android.view.ViewGroup
import com.newbrowser.pro.R
import java.util.Locale
import java.lang.InterruptedException
import com.google.android.material.snackbar.Snackbar
import android.graphics.RectF
import de.mrapp.android.util.DisplayUtil
import de.mrapp.android.util.ThemeUtil
import com.google.android.material.snackbar.BaseTransientBottomBar.BaseCallback
import androidx.core.content.ContextCompat
import android.preference.PreferenceManager
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.core.view.OnApplyWindowInsetsListener
import androidx.core.view.ViewCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.newbrowser.pro.model.SearchEngine
import com.newbrowser.pro.ui.browser.BrowserActivity
import com.newbrowser.pro.ui.downloads.DownloadsActivity
import com.newbrowser.pro.ui.history.HistoryRecordsActivity
import com.newbrowser.pro.ui.home.search.adapter.SearchEngineAdapter
import com.newbrowser.pro.ui.settings.SettingsActivity
import de.mrapp.android.tabswitcher.*
import kotlinx.android.synthetic.main.activity_browser3.*
import kotlinx.android.synthetic.main.activity_tabs.*
import kotlinx.android.synthetic.main.activity_tabs.et_search_field
import kotlinx.android.synthetic.main.activity_tabs.ib_search_menu
import kotlinx.android.synthetic.main.activity_tabs.iv_search
import android.graphics.BitmapFactory
import android.util.Log
import androidx.core.content.edit
import com.newbrowser.pro.ui.home.HomeActivity
import com.newbrowser.pro.utils.*
import kotlinx.android.synthetic.main.activity_home.*
import kotlinx.android.synthetic.main.activity_tabs.rv_search_engines
import java.io.File


class TabsActivity : AppCompatActivity(), TabSwitcherListener {


    private var isPreviewAllTabs = true
    private var currentLanguage: String? = null

    private inner class State

    internal constructor(tab: Tab) : AbstractState(tab),
        AbstractDataBinder.Listener<ArrayAdapter<String?>?, Tab, ListView, Void?>,
        TabPreviewListener {
        private var adapter: ArrayAdapter<String?>? = null

        override fun onCanceled(
            dataBinder: AbstractDataBinder<ArrayAdapter<String?>?, Tab, ListView, Void?>
        ) {
        }

        override fun saveInstanceState(outState: Bundle) {
            if (adapter != null && !adapter!!.isEmpty) {
                val array = arrayOfNulls<String>(adapter!!.count)
                for (i in array.indices) {
                    array[i] = adapter!!.getItem(i)
                }
                outState.putStringArray(
                    String.format(ADAPTER_STATE_EXTRA, tab.title),
                    array
                )
            }
        }

        override fun restoreInstanceState(savedInstanceState: Bundle?) {
            if (savedInstanceState != null) {
                val key = String.format(ADAPTER_STATE_EXTRA, tab.title)
                val items = savedInstanceState.getStringArray(key)
                if (items != null && items.size > 0) {
                    adapter = ArrayAdapter(
                        this@TabsActivity,
                        android.R.layout.simple_list_item_1, items
                    )
                }
            }
        }

        override fun onLoadTabPreview(
            tabSwitcher: TabSwitcher,
            tab: Tab
        ): Boolean {
            return getTab() != tab || adapter != null
        }

        override fun onLoadData(
            dataBinder: AbstractDataBinder<ArrayAdapter<String?>?, Tab, ListView, Void?>,
            key: Tab,
            vararg params: Void?
        ): Boolean {
            return true
        }

        override fun onFinished(
            dataBinder: AbstractDataBinder<ArrayAdapter<String?>?, Tab, ListView, Void?>,
            key: Tab,
            data: ArrayAdapter<String?>?,
            view: ListView,
            vararg params: Void?
        ) {
            if (tab == key) {
                view.adapter = data
                adapter = data
                dataBinder.removeListener(this)
            }
        }
    }

    private inner class Decorator : StatefulTabSwitcherDecorator<State?>() {
        override fun onCreateState(
            context: Context,
            tabSwitcher: TabSwitcher,
            view: View, tab: Tab,
            index: Int, viewType: Int,
            savedInstanceState: Bundle?
        ): State? {
            if (viewType == 2) {
                val state: State = State(tab)
                tabSwitcher.addTabPreviewListener(state)
                if (savedInstanceState != null) {
                    state.restoreInstanceState(savedInstanceState)
                }
                return state
            }
            return null
        }

        override fun onClearState(state: State) {
            tabSwitcher!!.removeTabPreviewListener(state)
        }

        override fun onSaveInstanceState(
            view: View, tab: Tab,
            index: Int, viewType: Int,
            state: State?,
            outState: Bundle
        ) {
            state?.saveInstanceState(outState)
        }

        override fun onInflateView(
            inflater: LayoutInflater,
            parent: ViewGroup?, viewType: Int
        ): View {
            val view: View = inflater.inflate(R.layout.tab_text_view, parent, false)
            return view
        }

        public override fun onShowTab(
            context: Context,
            tabSwitcher: TabSwitcher, view: View,
            tab: Tab, index: Int, viewType: Int,
            state: State?,
            savedInstanceState: Bundle?
        ) {Log.d("StartSHOW", "Start")
            val previewSite = findViewById<ImageView>(R.id.preview_site)
            val parameters = tab.parameters
            val path = parameters?.getInt(VIEW_TYPE_EXTRA) ?: 0
            if(previewSite.drawable != null){
                Log.d("Start", "Start")
                startActivity(BrowserActivity.newIntent(this@TabsActivity, getSharedPreferences(if(!isIncognitoMode(this@TabsActivity)) nameTabs else nameTabsOfIncognito, Context.MODE_PRIVATE).getString(path.toString(), null)!!.split("/////?")[0], true, path))
            }else{
                val imgFile = File("$filesDir$path.png")

                if (imgFile.exists()) {
                    val myBitmap = BitmapFactory.decodeFile(imgFile.absolutePath)
                    previewSite.setImageBitmap(myBitmap)
                }
            }
        }

        override fun getViewTypeCount(): Int {
            return 3
        }

        override fun getViewType(tab: Tab, index: Int): Int {
            val parameters = tab.parameters
            return parameters?.getInt(VIEW_TYPE_EXTRA) ?: 0
        }
    }

    private class DataBinder

        (context: Context) :
        AbstractDataBinder<ArrayAdapter<String?>?, Tab, ListView, Void?>(context.applicationContext) {

        override fun doInBackground(key: Tab, vararg params: Void?): ArrayAdapter<String?>? {
            val array = arrayOfNulls<String>(10)
            for (i in array.indices) {
                array[i] = String.format(Locale.getDefault(), "%s, item %d", key.title, i + 1)
            }
            try {
                Thread.sleep(1000)
            } catch (e: InterruptedException) {
            }
            return ArrayAdapter(context, android.R.layout.simple_list_item_1, array)
        }

        override fun onPostExecute(
            view: ListView,
            data: ArrayAdapter<String?>?,
            duration: Long,
            vararg params: Void?
        ) {
            if (data != null) {
                view.adapter = data
            }
        }
    }

    private var tabSwitcher: TabSwitcher? = null

    private var decorator: Decorator? = null

    private var snackbar: Snackbar? = null

    private var dataBinder: DataBinder? = null

    private fun createWindowInsetsListener(): OnApplyWindowInsetsListener {
        return OnApplyWindowInsetsListener { v, insets ->
            val left = insets.systemWindowInsetLeft
            val top = insets.systemWindowInsetTop
            val right = insets.systemWindowInsetRight
            val bottom = insets.systemWindowInsetBottom
            tabSwitcher!!.setPadding(left, top, right, bottom)
            var touchableAreaTop = top.toFloat()
            if (tabSwitcher!!.layout == Layout.TABLET) {
                touchableAreaTop += resources
                    .getDimensionPixelSize(R.dimen.tablet_tab_container_height).toFloat()
            }
            val touchableArea = RectF(
                left.toFloat(),
                touchableAreaTop,
                (DisplayUtil.getDisplayWidth(this@TabsActivity) - right).toFloat(),
                touchableAreaTop +
                        ThemeUtil.getDimensionPixelSize(this@TabsActivity, R.attr.actionBarSize)
            )
            tabSwitcher!!.addDragGesture(
                SwipeGesture.Builder().setTouchableArea(touchableArea).create()
            )
            tabSwitcher!!.addDragGesture(
                PullDownGesture.Builder().setTouchableArea(touchableArea).create()
            )
            insets
        }
    }

    private fun createTabSwitcherButtonListener(): View.OnClickListener {
        return View.OnClickListener {
            isPreviewAllTabs = true
            tabSwitcher!!.toggleSwitcherVisibility() }
    }

//    private fun createUndoSnackbarListener(
//        snackbar: Snackbar,
//        index: Int,
//        vararg tabs: Tab
//    ): View.OnClickListener {
//        return View.OnClickListener {
//            snackbar.setAction(null, null)
//            if (tabSwitcher!!.isSwitcherShown) {
//                tabSwitcher!!.addAllTabs(tabs, index)
//            } else if (tabs.size == 1) {
//                tabSwitcher!!.addTab(tabs[0], 0, createPeekAnimation())
//            }
//        }
//    }

//    private fun createUndoSnackbarCallback(
//        vararg tabs: Tab
//    ): BaseCallback<Snackbar?> {
//        return object : BaseCallback<Snackbar?>() {
//            override fun onDismissed(snackbar: Snackbar?, event: Int) {
//                if (event != DISMISS_EVENT_ACTION) {
//                    for (tab in tabs) {
//                        val parameters = tab.parameters
//                        val path = parameters?.getInt(VIEW_TYPE_EXTRA) ?: 0
//                        val removeItem = "${tab.title}/////?$path"
//
//                        tabSwitcher!!.clearSavedState(tab)
//                        decorator!!.clearState(tab)
//                        currentTabs.remove(removeItem)
//                        getSharedPreferences(nameTabs, Context.MODE_PRIVATE).edit {
//                            this.remove(path.toString())
//                        }
//
//                        val imgFile = File("$filesDir$path.png")
//                        imgFile.delete()
//                    }
//
//                }
//            }
//        }
//    }

//    private fun createPeekAnimation(): Animation {
//        return PeekAnimation.Builder().setX(tabSwitcher!!.width / 2f).create()
//    }
//
//    private val navigationMenuItem: View?
//        private get() {
//            val toolbars = tabSwitcher!!.toolbars
//            if (toolbars != null) {
//                val toolbar = if (toolbars.size > 1) toolbars[1] else toolbars[0]
//                val size = toolbar.childCount
//                for (i in 0 until size) {
//                    val child = toolbar.getChildAt(i)
//                    if (child is ImageButton) {
//                        return child
//                    }
//                }
//            }
//            return null
//        }

    private fun createTab(title: String, index: Int): Tab {
        val tab = Tab(title)
        val parameters = Bundle()
        parameters.putInt(VIEW_TYPE_EXTRA, index)
        tab.parameters = parameters
        return tab
    }

    override fun onSwitcherShown(tabSwitcher: TabSwitcher) {}
    override fun onSwitcherHidden(tabSwitcher: TabSwitcher) {
        if (snackbar != null) {
            snackbar!!.dismiss()
        }
    }

    override fun onSelectionChanged(
        tabSwitcher: TabSwitcher,
        selectedTabIndex: Int,
        selectedTab: Tab?
    ) {
    }

    override fun onTabAdded(
        tabSwitcher: TabSwitcher, index: Int,
        tab: Tab, animation: Animation
    ) {
        TabSwitcher.setupWithMenu(tabSwitcher, createTabSwitcherButtonListener())
    }

    override fun onTabRemoved(
        tabSwitcher: TabSwitcher, index: Int,
        tab: Tab, animation: Animation
    ) {
        val text: CharSequence = getString(R.string.removed_tab_snackbar, tab.title)
        //showUndoSnackbar(text, index, tab)
        TabSwitcher.setupWithMenu(tabSwitcher, createTabSwitcherButtonListener())
        val parameters = tab.parameters
        val path = parameters?.getInt(VIEW_TYPE_EXTRA) ?: 0
        val removeItem = "${tab.title}/////?$path"

        tabSwitcher!!.clearSavedState(tab)
        decorator!!.clearState(tab)
        currentTabs.remove(removeItem)
        if(!isChangeMode){
            getSharedPreferences(if(!isIncognitoMode(this)) nameTabs else nameTabsOfIncognito, Context.MODE_PRIVATE).edit {
                this.remove(path.toString())
            }
            val imgFile = File("$filesDir$path.png")
            imgFile.delete()
        }
    }

    override fun onAllTabsRemoved(
        tabSwitcher: TabSwitcher,
        tabs: Array<Tab>,
        animation: Animation
    ) {
        val text: CharSequence = getString(R.string.cleared_tabs_snackbar)
        //showUndoSnackbar(text, 0, *tabs)
        TabSwitcher.setupWithMenu(tabSwitcher, createTabSwitcherButtonListener())
        Log.d("removeAllTabs", "removeAllTabs")
        for (tab in tabs) {
            val parameters = tab.parameters
            val path = parameters?.getInt(VIEW_TYPE_EXTRA) ?: 0
            val removeItem = "${tab.title}/////?$path"

            tabSwitcher!!.clearSavedState(tab)
            decorator!!.clearState(tab)
            currentTabs.remove(removeItem)
            if(!isChangeMode){
                getSharedPreferences(if(!isIncognitoMode(this)) nameTabs else nameTabsOfIncognito, Context.MODE_PRIVATE).edit {
                this.remove(path.toString())
            }
                val imgFile = File("$filesDir$path.png")
                imgFile.delete()
            }
        }
    }

    override fun setTheme(resid: Int) {
        val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this)
        val themeKey = getString(R.string.theme_preference_key)
        val themeDefaultValue = getString(R.string.theme_preference_default_value)
        val theme = Integer.valueOf(sharedPreferences.getString(themeKey, themeDefaultValue))
        if (theme != 0) {
            super.setTheme(R.style.AppTheme_Translucent_Dark)
        } else {
            super.setTheme(R.style.AppTheme_Translucent_Light)
        }
    }

    private var searchEngineAdapter: SearchEngineAdapter? = null

    private val nameTabs = "tabs"
    private val nameTabsOfIncognito = "tabs_incognito"
    private var currentTabs = mutableListOf<String>()

    private var isChangeMode = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tabs)

        currentLanguage = getSharedPreferences(Constants.Settings.SETTINGS_LANGUAGE, Context.MODE_PRIVATE).getString(
            Constants.Settings.SETTINGS_LANGUAGE, "en")
        dataBinder = DataBinder(this)
        decorator = Decorator()
        tabSwitcher = findViewById(R.id.tab_switcher)
        tabSwitcher!!.clearSavedStatesWhenRemovingTabs(false)
        ViewCompat.setOnApplyWindowInsetsListener(tabSwitcher!!, createWindowInsetsListener())
        tabSwitcher!!.decorator = decorator!!
        tabSwitcher!!.addListener(this)
        tabSwitcher!!.setEmptyView(R.layout.empty_view)
        tabSwitcher!!.showToolbars(false)
        for(item in getSharedPreferences(if(!isIncognitoMode(this)) nameTabs else nameTabsOfIncognito, Context.MODE_PRIVATE).all){
            val chapters = item.value.toString().split("/////?")
            currentTabs.add(item.value.toString())
            tabSwitcher!!.addTab(createTab(chapters[2], chapters[1].toInt()), currentTabs.size-1)
        }

        tabSwitcher!!.toggleSwitcherVisibility()

        TabSwitcher.setupWithMenu(tabSwitcher!!, createTabSwitcherButtonListener())
        initRecyclers()
        setOnClickListeners()
        setOnActionListeners()
        setSearchEngine()
        incognitoMode()
    }

    private fun setSearchEngine() {
        val searchEngine = getSelectedSearchEngine(this)

        if (searchEngine != null) {
            saveSelectedSearchEngine(this, searchEngine)
            searchEngineAdapter?.selectItem(searchEngine)
        } else {
            val googleSearchEngine = getSearchEngines(this)[0]
            saveSelectedSearchEngine(this, googleSearchEngine)
            searchEngineAdapter?.selectItem(googleSearchEngine)
        }
    }

    private fun setOnActionListeners() {
        et_search_field?.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                onSearchClicked()
                return@setOnEditorActionListener true
            }
            false
        }
    }

    private fun setOnClickListeners() {
        iv_search?.setOnClickListener {
            onSearchClicked()
        }
        iv_add_tabs?.setOnClickListener {
            Log.d("iv_add_tabs", "iv_add_tabs")
            startActivity(HomeActivity.newIntent(this))
        }
        close.setOnClickListener {
            finish()
        }
        ib_search_menu?.setOnClickListener {
            showMenu()
        }
        rl_incognito.setOnClickListener {
            incognitoMode(true)
        }
    }

    private fun incognitoMode(isClick: Boolean = false) {
        if(isClick){
            isChangeMode = true
            tabSwitcher!!.clear()
            currentTabs.clear()
            if (isIncognitoMode(this)) {
                offIncognitoMode()
                setIsIncognitoMode(this, close.isSelected)
                for(item in getSharedPreferences(nameTabs, Context.MODE_PRIVATE).all){
                    Log.d("nameTabs", "nameTabs")
                    val chapters = item.value.toString().split("/////?")
                    tabSwitcher!!.addTab(createTab(chapters[2], chapters[1].toInt()))
                    currentTabs.add(item.value.toString())
                }
            } else {
                onIncognitoMode()
                setIsIncognitoMode(this, close.isSelected)
                for(item in getSharedPreferences(nameTabsOfIncognito, Context.MODE_PRIVATE).all){
                    Log.d("nameTabs", "nameTabs")
                    val chapters = item.value.toString().split("/////?")
                    tabSwitcher!!.addTab(createTab(chapters[2], chapters[1].toInt()))
                    currentTabs.add(item.value.toString())
                }
            }
            isChangeMode = false
        }else{
            isChangeMode = false
            if (isIncognitoMode(this)) {
                onIncognitoMode()
            }else{
                offIncognitoMode()
            }
        }

    }

    private fun onIncognitoMode() {
        close.isSelected = true
        rl_incognito.isSelected = true
        iv_incognito.setColorFilter(ContextCompat.getColor(this, R.color.incognito_dark))
        cl_buttons_tabs.setBackgroundColor(ContextCompat.getColor(this, R.color.incognito_dark))
        iv_add_tabs.setImageResource(R.drawable.ic_add_tab_incognito)
        cl_main_tabs.setBackgroundColor(ContextCompat.getColor(this, R.color.incognito_dark))
        tab_switcher.setBackgroundColor(ContextCompat.getColor(this, R.color.incognito_dark))
    }

    private fun offIncognitoMode() {
        close.isSelected = false
        rl_incognito.isSelected = false
        iv_incognito.setColorFilter(ContextCompat.getColor(this, R.color.grey_2))
        cl_buttons_tabs.setBackgroundColor(ContextCompat.getColor(this, R.color.white))
        iv_add_tabs.setImageResource(R.drawable.ic_add_tab)
        cl_main_tabs.setBackgroundColor(ContextCompat.getColor(this, R.color.white))
        tab_switcher.setBackgroundColor(ContextCompat.getColor(this, R.color.white))
    }

    private fun showMenu() {
        val menu =
            PopupMenu(
                this,
                ib_search_menu
            )
        menu.inflate(R.menu.tabs_menu)
        menu.setOnMenuItemClickListener {
            when (it.itemId) {
                R.id.clear_tabs_menu_item -> {
                    tabSwitcher!!.clear()
                }
                R.id.item_settings -> {
                    startActivity(SettingsActivity.newIntent(this))
                }
                R.id.item_history -> {
                    startActivity(HistoryRecordsActivity.newIntent(this))
                }
                R.id.item_downloads -> {
                    startActivity(DownloadsActivity.newIntent(this))
                }
            }
            false
        }

        menu.show()
    }

    private fun onSearchClicked() {
        val searchText = et_search_field?.text?.toString()

        if (!searchText.isNullOrEmpty()) {
            startActivity(BrowserActivity.newIntent(this, searchText))
        } else {
            Toast.makeText(this, getString(R.string.search_empty_error), Toast.LENGTH_SHORT).show()
        }
    }

    private fun initRecyclers() {
        searchEngineAdapter = SearchEngineAdapter(arrayListOf()) {
            onSearchEngineClicked(it)
        }
        rv_search_engines?.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        rv_search_engines?.adapter = searchEngineAdapter

        searchEngineAdapter?.updateData(getSearchEngines(this))
    }

    private fun onSearchEngineClicked(searchEngine: SearchEngine) {
        saveSelectedSearchEngine(this, searchEngine)
        searchEngineAdapter?.selectItem(searchEngine)
    }

    override fun onPause() {
        super.onPause()

        val previewSite = findViewById<ImageView>(R.id.preview_site)
        if(previewSite != null){
            if(previewSite.drawable != null){
                finish()
            }
        }
    }

    override fun onResume() {
        super.onResume()

        val newestLanguage = getSharedPreferences(Constants.Settings.SETTINGS_LANGUAGE, Context.MODE_PRIVATE).getString(
            Constants.Settings.SETTINGS_LANGUAGE, "en")
        if(currentLanguage != newestLanguage){
            recreate()
        }
    }

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(applySelectedAppLanguage(base))
    }

    private fun applySelectedAppLanguage(context: Context): Context {
        val newestLanguage = context.getSharedPreferences(Constants.Settings.SETTINGS_LANGUAGE, Context.MODE_PRIVATE).getString(
            Constants.Settings.SETTINGS_LANGUAGE, "en")
        val locale = Locale(newestLanguage)
        val newConfig = Configuration(context.resources.configuration)
        Locale.setDefault(locale)
        newConfig.setLocale(locale)
        return context.createConfigurationContext(newConfig)
    }

    companion object {
        fun newIntent(context: Context) = Intent(context, TabsActivity::class.java)
        private val VIEW_TYPE_EXTRA = TabsActivity::class.java.name + "::ViewType"

        private val ADAPTER_STATE_EXTRA = State::class.java.name + "::%s::AdapterState"
    }
}