package com.newbrowser.pro.utils

import com.newbrowser.pro.R
import com.newbrowser.pro.model.Bookmark

fun getBookmarks(): ArrayList<Bookmark> {

    val arr = arrayListOf<Bookmark>()

    arr.add(Bookmark(
        1,
        "Facebook",
        "https://www.facebook.com/",
        null,
        R.drawable.ic_facebook
    ))

    arr.add(Bookmark(
        2,
        "YouTube",
        "https://www.youtube.com/",
        null,
        R.drawable.ic_youtube
    ))

    arr.add(Bookmark(
        3,
        "Twitter",
        "https://www.twitter.com/",
        null,
        R.drawable.ic_twitter
    ))

    arr.add(Bookmark(
        4,
        "VK",
        "https://www.vk.com/",
        null,
        R.drawable.ic_vk
    ))

    arr.add(Bookmark(
        5,
        "Odnoklassniki",
        "https://www.ok.ru/",
        null,
        R.drawable.ic_odnoklassniki
    ))

    arr.add(Bookmark(
        6,
        "Hot Coubs - The Biggest Video Meme Platform",
        "https://coub.com/",
        "https://coubsecureassets-a.akamaihd.net/assets/og/coub_og_image-ac413e288cf569b3fec8bcce869961e530d0f70adef8f94fb47883590e4d57fa.png",
        null,
        true
    ))

    arr.add(Bookmark(
        7,
        "Первый канал онлайн",
        "https://www.1tv.ru/",
        "https://www.1tv.ru/img/social-stub-image.jpg",
        null,
        true
    ))

    arr.add(Bookmark(
        8,
        "Новости Татарстана",
        "https://www.rbc.ru/",
        "https://s.rbk.ru/v10_rbcnews_static/current/images/rbc-share.png",
        null,
        true
    ))

    arr.add(Bookmark(
        9,
        "Amazon.com. Spend less. Smile more.",
        "https://www.amazon.com/",
        "http://g-ec2.images-amazon.com/images/G/01/social/api-share/amazon_logo_500500._V323939215_.png",
        null,
        true
    ))

    return arr
}