package com.newbrowser.pro.ui.downloads

import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.gson.Gson
import com.newbrowser.pro.NewBrowserPro
import com.newbrowser.pro.R
import com.newbrowser.pro.database.downloads.DownloadModelsViewModel
import com.newbrowser.pro.database.downloads.DownloadModelsViewModelFactory
import com.newbrowser.pro.model.DownloadModel
import com.newbrowser.pro.ui.downloads.adapter.DownloadsAdapter
import kotlinx.android.synthetic.main.activity_downloads.*
import timber.log.Timber
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import com.newbrowser.pro.BuildConfig
import com.newbrowser.pro.utils.Constants
import java.io.File
import java.util.*
import kotlin.collections.ArrayList


class DownloadsActivity : AppCompatActivity() {

    companion object {
        fun newIntent(context: Context) = Intent(context, DownloadsActivity::class.java)
    }

    private var adapter: DownloadsAdapter? = null

    private val downloadsViewModel: DownloadModelsViewModel by viewModels {
        DownloadModelsViewModelFactory((this.application as NewBrowserPro).downloadsRepository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_downloads)

        setOnClickListeners()
        initRecycler()
        observeDownloads()
    }

    private fun setOnClickListeners() {
        iv_back?.setOnClickListener {
            finish()
        }
    }

    private fun initRecycler() {
        adapter = DownloadsAdapter(arrayListOf()) {
            onDownloadClicked(it)
        }
        rv_downloads?.layoutManager = LinearLayoutManager(this)
        rv_downloads?.adapter = adapter
    }

    private fun onDownloadClicked(download: DownloadModel) {
        Timber.d("TAG_DOWNLOAD_DETAIL_1: ${Gson().toJson(download)}")
        Timber.d("TAG_DOWNLOAD_DETAIL_2: ${download.filePath}")

        val file = File(download.filePath)
        val map = MimeTypeMap.getSingleton()
        val ext = MimeTypeMap.getFileExtensionFromUrl(file.getName())
        var type = map.getMimeTypeFromExtension(ext)

        if (type == null) type = "*/*"

        val intent = Intent(Intent.ACTION_VIEW)
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
//        val data: Uri = Uri.fromFile(file)
        val data: Uri = FileProvider.getUriForFile(
            this,
            BuildConfig.APPLICATION_ID + ".provider",
            file
        )

        intent.setDataAndType(data, type)
        startActivity(intent)
    }

    private fun observeDownloads() {
        downloadsViewModel.allDownloadModels.observe(this, Observer {
            it?.let {
                adapter?.updateData(ArrayList(it))
            }
        })
    }

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(applySelectedAppLanguage(base))
    }

    private fun applySelectedAppLanguage(context: Context): Context {
        val newestLanguage = context.getSharedPreferences(Constants.Settings.SETTINGS_LANGUAGE, Context.MODE_PRIVATE).getString(
            Constants.Settings.SETTINGS_LANGUAGE, "en")
        val locale = Locale(newestLanguage)
        val newConfig = Configuration(context.resources.configuration)
        Locale.setDefault(locale)
        newConfig.setLocale(locale)
        return context.createConfigurationContext(newConfig)
    }
}