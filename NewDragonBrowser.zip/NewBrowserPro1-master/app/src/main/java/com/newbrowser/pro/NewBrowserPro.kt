package com.newbrowser.pro

import android.app.Application
import com.newbrowser.pro.database.bookmarks.BookmarksRepository
import com.newbrowser.pro.database.AppDatabase
import com.newbrowser.pro.database.downloads.DownloadsRepository
import com.newbrowser.pro.database.history.HistoryRecordsDao
import com.newbrowser.pro.database.history.HistoryRecordsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import timber.log.Timber

class NewBrowserPro : Application() {

    val applicationScope = CoroutineScope(SupervisorJob())
    val database by lazy { AppDatabase.getDatabase(this, applicationScope) }
    val bookmarksRepository by lazy { BookmarksRepository(database.bookmarksDao()) }
    val historyRecordsRepository by lazy { HistoryRecordsRepository(database.historyRecordsDao()) }
    val downloadsRepository by lazy { DownloadsRepository(database.downloadsDao()) }

    override fun onCreate() {
        super.onCreate()

        initTimber()
    }

    private fun initTimber() {
        Timber.plant(Timber.DebugTree())
    }
}