package com.newbrowser.pro.utils.ogparser

import com.newbrowser.pro.model.OpenGraphResult

interface OpenGraphCallback {
    fun onPostResponse(openGraphResult: OpenGraphResult)
    fun onError(error: String)
}