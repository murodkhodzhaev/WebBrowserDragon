package com.newbrowser.pro.ui.settings

import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.view.*
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import androidx.core.content.edit
import com.google.android.material.textfield.TextInputLayout
import com.newbrowser.pro.R
import com.newbrowser.pro.model.Settings
import com.newbrowser.pro.ui.home.HomeActivity
import com.newbrowser.pro.utils.Constants.Settings.SETTINGS_LANGUAGE
import com.newbrowser.pro.utils.settings.getSettings
import com.newbrowser.pro.utils.settings.saveSettings
import kotlinx.android.synthetic.main.activity_settings.*
import java.util.*
import android.content.DialogInterface

import android.view.ViewGroup

import android.view.LayoutInflater

import android.view.View
import androidx.webkit.ProxyConfig
import androidx.webkit.ProxyController
import androidx.webkit.WebViewFeature
import com.newbrowser.pro.utils.Constants.Settings.SETTINGS_PROXY
import com.newbrowser.pro.utils.Constants.Settings.SETTINGS_USER_AGENT
import java.util.concurrent.Executor


class SettingsActivity : AppCompatActivity() {

    companion object {
        fun newIntent(context: Context) = Intent(context, SettingsActivity::class.java)
    }

    private var settings: Settings? = null
    private var languagesArray: Array<String>? = null
    private var languagesCodeArray: Array<String>? = null

    private val REQUEST_DIRECTORY = 10

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        languagesArray = resources.getStringArray(R.array.languages)
        languagesCodeArray = resources.getStringArray(R.array.languages_code)

        setOnClickListeners()
        setData()
    }

    override fun onCreateContextMenu(menu: ContextMenu, v: View, menuInfo: ContextMenu.ContextMenuInfo?) {
        for((index, language) in languagesArray!!.withIndex()){
            menu.add(language)
                .setOnMenuItemClickListener { item: MenuItem? ->
                    onChangeDefaultLanguage(languagesCodeArray!![index])
                    true
                }
        }
    }


    private fun setOnClickListeners() {
        iv_back?.setOnClickListener { onBackPressed() }
        iv_without_images_checkbox?.setOnClickListener { onWithoutImagesClicked() }
        cl_without_images?.setOnClickListener { onWithoutImagesClicked() }
        iv_block_ads_checkbox?.setOnClickListener { onBlockAdsClicked() }
        cl_block_ads?.setOnClickListener { onBlockAdsClicked() }
        iv_enable_js_checkbox?.setOnClickListener { onEnableJavaScriptClicked() }
        cl_enable_js?.setOnClickListener { onEnableJavaScriptClicked() }
        cl_colored_mode?.setOnClickListener { onEnableColorModeScriptClicked() }
        iv_colored_mode_checkbox?.setOnClickListener { onEnableColorModeScriptClicked() }
        registerForContextMenu(cl_language)
        cl_language?.setOnClickListener { openContextMenu(it) }
        cl_new_tab?.setOnClickListener { startActivity(HomeActivity.newIntent(this)) }
        cl_user_agent?.setOnClickListener {
            val builder = AlertDialog.Builder(this@SettingsActivity)
            builder.setTitle(getString(R.string.user_agent))
            val viewInflated: View = LayoutInflater.from(this@SettingsActivity)
                .inflate(R.layout.input_user_agent, parent as ViewGroup?, false)
            val inputUserAgent = viewInflated.findViewById<EditText>(R.id.input_user_agent)
            if(tv_user_agent_description?.text.toString().isNotEmpty()) inputUserAgent.setText(tv_user_agent_description?.text.toString())
            builder.setView(viewInflated)
            builder.setPositiveButton(
                android.R.string.ok
            ) { dialog, which ->
                dialog.dismiss()
                if(inputUserAgent.text.isEmpty()){
                    tv_user_agent_description?.text = getString(R.string.settings_http_default)
                    setUserAgent(null)
                }else{
                    tv_user_agent_description?.text = inputUserAgent.text.toString()
                    setUserAgent(inputUserAgent.text.toString())
                }

                //m_Text = input.text.toString()
            }
            builder.setNegativeButton(
                android.R.string.cancel
            ) { dialog, which -> dialog.cancel() }

            builder.show()
        }
        cl_proxy?.setOnClickListener {
            val builder = AlertDialog.Builder(this@SettingsActivity)
            builder.setTitle(getString(R.string.proxy))
            val viewInflated: View = LayoutInflater.from(this@SettingsActivity)
                .inflate(R.layout.input_proxy, parent as ViewGroup?, false)
            val inputHost = viewInflated.findViewById<EditText>(R.id.input_host)
            val inputPort = viewInflated.findViewById<EditText>(R.id.input_port)

            if(tv_proxy_description?.text.toString().contains(":")){
                val chapterProxy = tv_proxy_description?.text.toString().split(":")
                inputHost.setText(chapterProxy[0])
                inputPort.setText(chapterProxy[1])
            }

            builder.setView(viewInflated)
            builder.setPositiveButton(
                android.R.string.ok
            ) { dialog, which ->
                dialog.dismiss()
                if(inputHost.text.isEmpty() && inputPort.text.isEmpty()){
                    tv_proxy_description?.text = getString(R.string.no)
                    setProxy(null)
                }else{
                    if (WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) {
                        val proxyUrl = "${inputHost.text}:${inputPort.text}"
                        setProxy(proxyUrl)
                        tv_proxy_description?.text = proxyUrl
                        val proxyConfig: ProxyConfig = ProxyConfig.Builder()
                            .addProxyRule(proxyUrl)
                            .addDirect()
                            .build()
                        ProxyController.getInstance().setProxyOverride(proxyConfig, object : Executor {
                            override fun execute(command: Runnable) {

                            }
                        }, Runnable { Log.w("TAG", "WebView proxy") })
                    }
                }

                //m_Text = input.text.toString()
            }
            builder.setNegativeButton(
                android.R.string.cancel
            ) { dialog, which -> dialog.cancel() }

            builder.show()
        }
        //cl_download_path?.setOnClickListener {
//            val chooserIntent = Intent(
//                this,
//                DirectoryChooserActivity::class.java
//            )
//            val config = DirectoryChooserConfig.builder().newDirectoryName("Выберите каталог")
//                .allowReadOnlyDirectory(true).allowNewDirectoryNameModification(true).build()
//
//
//            chooserIntent.putExtra(
//                DirectoryChooserActivity.EXTRA_CONFIG,
//                config);
//
//            startActivityForResult(chooserIntent, REQUEST_DIRECTORY);
//            val chooserIntent = Intent(this, DirectoryChooserActivity::class.java)
//
//            val config = DirectoryChooserConfig.builder()
//                .newDirectoryName("DirChooserSample")
//                .allowReadOnlyDirectory(true)
//                .allowNewDirectoryNameModification(true)
//                .initialDirectory(
//                    Environment.getExternalStorageDirectory().toString() + separator
//                )
//                .build()
//
//            chooserIntent.putExtra(DirectoryChooserActivity.EXTRA_CONFIG, config)
//            startActivityForResult(chooserIntent, REQUEST_DIRECTORY)
        //}
    }

//    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
//        super.onActivityResult(requestCode, resultCode, data)
//        if (requestCode == REQUEST_DIRECTORY) {
//            if (resultCode == DirectoryChooserActivity.RESULT_CODE_DIR_SELECTED) {
//                Log.d("DIRECTORY" , data!!.getStringExtra(DirectoryChooserActivity.RESULT_SELECTED_DIR)!!
//                )
//                // Nothing selected
//            }
//        }
//    }

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(applySelectedAppLanguage(base))
    }

    private fun applySelectedAppLanguage(context: Context): Context {
        val newestLanguage = context.getSharedPreferences(SETTINGS_LANGUAGE, Context.MODE_PRIVATE).getString(SETTINGS_LANGUAGE, "en")
        val locale = Locale(newestLanguage)
        val newConfig = Configuration(context.resources.configuration)
        Locale.setDefault(locale)
        newConfig.setLocale(locale)
        return context.createConfigurationContext(newConfig)
    }

    private fun onChangeDefaultLanguage(code: String) {
        getSharedPreferences(SETTINGS_LANGUAGE, Context.MODE_PRIVATE).edit {
            this.putString(SETTINGS_LANGUAGE, code)
        }
        recreate()
    }

    private fun onWithoutImagesClicked() {
        if(settings!!.withoutImages) {
            saveSettings(this, settings!!.copy(withoutImages = false))
            iv_without_images_checkbox?.setImageResource(R.drawable.ic_checkbox_disabled)
        }
        else {
            saveSettings(this, settings!!.copy(withoutImages = true))
            iv_without_images_checkbox?.setImageResource(R.drawable.ic_checkbox_enabled)
        }
        settings = getSettings(this)
    }

    private fun onBlockAdsClicked() {
        if(settings!!.blockAds) {
            saveSettings(this, settings!!.copy(blockAds = false))
            iv_block_ads_checkbox?.setImageResource(R.drawable.ic_checkbox_disabled)
        }
        else {
            saveSettings(this, settings!!.copy(blockAds = true))
            iv_block_ads_checkbox?.setImageResource(R.drawable.ic_checkbox_enabled)
        }
        settings = getSettings(this)
    }

    private fun onEnableJavaScriptClicked() {
        if(settings!!.enableJavaScript == true) {
            saveSettings(this, settings!!.copy(enableJavaScript = false))
            iv_enable_js_checkbox?.setImageResource(R.drawable.ic_checkbox_disabled)
        }
        else {
            saveSettings(this, settings!!.copy(enableJavaScript = true))
            iv_enable_js_checkbox?.setImageResource(R.drawable.ic_checkbox_enabled)
        }
        settings = getSettings(this)
    }

    private fun onEnableColorModeScriptClicked() {
        if(settings!!.enableColorMode == true) {
            saveSettings(this, settings!!.copy(enableColorMode = false))
            iv_colored_mode_checkbox?.setImageResource(R.drawable.ic_checkbox_disabled)
        }
        else {
            saveSettings(this, settings!!.copy(enableColorMode = true))
            iv_colored_mode_checkbox?.setImageResource(R.drawable.ic_checkbox_enabled)
        }
        settings = getSettings(this)
    }

    private fun setData() {
        val currentCode = getSharedPreferences(SETTINGS_LANGUAGE, Context.MODE_PRIVATE).getString(SETTINGS_LANGUAGE, "en")

        loop@ for((index, code) in languagesCodeArray!!.withIndex()){
            if(code == currentCode){
                tv_language_description?.text = languagesArray!![index]
                break@loop
            }
        }

        settings = getSettings(this)

        if(settings!!.withoutImages == true) {
            iv_without_images_checkbox?.setImageResource(R.drawable.ic_checkbox_enabled)
        }
        else {
            iv_without_images_checkbox?.setImageResource(R.drawable.ic_checkbox_disabled)
        }

        if(settings!!.blockAds == true) {
            iv_block_ads_checkbox?.setImageResource(R.drawable.ic_checkbox_enabled)
        }
        else {
            iv_block_ads_checkbox?.setImageResource(R.drawable.ic_checkbox_disabled)
        }

        if(settings!!.enableJavaScript == true) {
            iv_enable_js_checkbox?.setImageResource(R.drawable.ic_checkbox_enabled)
        }
        else {
            iv_enable_js_checkbox?.setImageResource(R.drawable.ic_checkbox_disabled)
        }

        if(settings!!.enableColorMode == true) {
            iv_colored_mode_checkbox?.setImageResource(R.drawable.ic_checkbox_enabled)
        }
        else {
            iv_colored_mode_checkbox?.setImageResource(R.drawable.ic_checkbox_disabled)
        }

        val proxy = getProxy()
        val userAgent = getUserAgent()
        settings!!.httpProxy = proxy
        settings!!.userAgent = userAgent
        tv_proxy_description?.text = proxy
        tv_user_agent_description?.text = userAgent
        tv_download_path_description?.text = settings!!.downloadPath
        tv_new_tab_description?.text = settings!!.newTab
    }

    private fun getProxy(): String{
        return getSharedPreferences(SETTINGS_PROXY, Context.MODE_PRIVATE).getString(SETTINGS_PROXY, getString(R.string.no))!!
    }

    private fun setProxy(proxy: String?){
        getSharedPreferences(SETTINGS_PROXY, Context.MODE_PRIVATE).edit {
            this.putString(SETTINGS_PROXY, proxy)
        }
    }

    private fun getUserAgent(): String{
        return getSharedPreferences(SETTINGS_USER_AGENT, Context.MODE_PRIVATE).getString(SETTINGS_USER_AGENT, getString(R.string.settings_http_default))!!
    }

    private fun setUserAgent(userAgent: String?){
        getSharedPreferences(SETTINGS_USER_AGENT, Context.MODE_PRIVATE).edit {
            this.putString(SETTINGS_USER_AGENT, userAgent)
        }
    }

}