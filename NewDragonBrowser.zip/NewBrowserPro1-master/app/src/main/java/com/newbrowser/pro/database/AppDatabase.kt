package com.newbrowser.pro.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.newbrowser.pro.database.bookmarks.BookmarksDao
import com.newbrowser.pro.database.downloads.DownloadsDao
import com.newbrowser.pro.database.history.HistoryRecordsDao
import com.newbrowser.pro.model.Bookmark
import com.newbrowser.pro.model.DownloadModel
import com.newbrowser.pro.model.HistoryRecord
import com.newbrowser.pro.utils.Constants
import kotlinx.coroutines.CoroutineScope

@Database(
    entities = [Bookmark::class, HistoryRecord::class, DownloadModel::class],
    version = 7,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun bookmarksDao(): BookmarksDao
    abstract fun historyRecordsDao(): HistoryRecordsDao
    abstract fun downloadsDao(): DownloadsDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(
            context: Context,
            scope: CoroutineScope
        ): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    Constants.Database.DATABASE_NAME
                )
                    .fallbackToDestructiveMigration()
                    .allowMainThreadQueries()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}