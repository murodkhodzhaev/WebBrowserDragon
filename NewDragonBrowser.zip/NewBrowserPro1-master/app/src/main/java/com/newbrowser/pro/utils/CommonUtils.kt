package com.newbrowser.pro.utils

import android.content.Context

fun isFirstLaunch(context: Context): Boolean {
    return context.getSharedPreferences(Constants.App.APP, Context.MODE_PRIVATE)
        .getBoolean(Constants.App.APP_IS_FIRST_LAUNCH, true)
}

fun setIsFirstLaunch(context: Context, isFirstLaunch: Boolean) {
    context.getSharedPreferences(Constants.App.APP, Context.MODE_PRIVATE)
        .edit()
        .putBoolean(Constants.App.APP_IS_FIRST_LAUNCH, isFirstLaunch)
        .apply()
}

fun isIncognitoMode(context: Context): Boolean {
    return context.getSharedPreferences(Constants.App.APP, Context.MODE_PRIVATE)
        .getBoolean(Constants.App.IS_INCOGNITO_MODE, false)
}

fun setIsIncognitoMode(context: Context, isIncognitoMode: Boolean) {
    context.getSharedPreferences(Constants.App.APP, Context.MODE_PRIVATE)
        .edit()
        .putBoolean(Constants.App.IS_INCOGNITO_MODE, isIncognitoMode)
        .apply()
}