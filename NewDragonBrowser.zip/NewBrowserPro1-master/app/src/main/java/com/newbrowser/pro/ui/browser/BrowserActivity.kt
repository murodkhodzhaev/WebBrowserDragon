package com.newbrowser.pro.ui.browser

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.net.http.SslError
import android.os.*
import androidx.appcompat.app.AppCompatActivity
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.webkit.*
import android.widget.PopupMenu
import android.widget.Toast
import androidx.activity.viewModels
import com.newbrowser.pro.NewBrowserPro
import com.newbrowser.pro.R
import com.newbrowser.pro.database.bookmarks.BookmarksViewModel
import com.newbrowser.pro.database.bookmarks.BookmarksViewModelFactory
import com.newbrowser.pro.database.history.HistoryRecordsViewModel
import com.newbrowser.pro.database.history.HistoryRecordsViewModelFactory
import com.newbrowser.pro.ui.downloads.DownloadsActivity
import com.newbrowser.pro.ui.history.HistoryRecordsActivity
import com.newbrowser.pro.utils.ogparser.OpenGraphCallback
import com.newbrowser.pro.utils.ogparser.OpenGraphParser
import kotlinx.android.synthetic.main.activity_browser3.*
import timber.log.Timber
import java.lang.Exception
import java.text.SimpleDateFormat
import java.util.*
import android.webkit.WebView
import android.webkit.WebView.HitTestResult
import androidx.core.content.edit
import com.newbrowser.pro.database.downloads.DownloadModelsViewModel
import com.newbrowser.pro.database.downloads.DownloadModelsViewModelFactory
import com.newbrowser.pro.ui.settings.SettingsActivity
import com.newbrowser.pro.ui.tabs.TabsActivity
import com.newbrowser.pro.utils.file.getMimeType
import com.newbrowser.pro.utils.file.getStringSizeLengthFile
import com.newbrowser.pro.utils.other.unit.BrowserUnit
import com.newbrowser.pro.utils.settings.getSettings
import kotlinx.android.synthetic.main.activity_browser3.b_tabs
import kotlinx.android.synthetic.main.activity_browser3.et_search_field
import kotlinx.android.synthetic.main.activity_browser3.ib_search_menu
import kotlinx.android.synthetic.main.activity_browser3.iv_search
import kotlinx.android.synthetic.main.activity_home.*
import java.net.URL
import android.content.res.Configuration
import com.newbrowser.pro.model.*
import com.newbrowser.pro.ui.home.HomeActivity
import com.newbrowser.pro.utils.*
import java.io.*
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import com.newbrowser.pro.utils.Constants.CheckUrl.NEWEST_URL_END
import com.newbrowser.pro.utils.Constants.CheckUrl.NEWEST_URL_START
import kotlinx.android.synthetic.main.activity_tabs.*
import java.io.IOException
import java.nio.charset.StandardCharsets.UTF_8

import org.json.JSONArray





class BrowserActivity : AppCompatActivity(), OpenGraphCallback {

    private var lastUrl: String? = null
    private var currentCount: Int = 0

    companion object {
        fun newIntent(context: Context, url: String? = null, isFromTabs: Boolean = false, countTab: Int? = null): Intent {
            val intent = Intent(context, BrowserActivity::class.java)
            intent.putExtra(EXTRA_URL, url)
            intent.putExtra(FROM_TABS, isFromTabs)
            intent.putExtra(COUNT_TAB, countTab)
            return intent
        }

        const val EXTRA_URL = "extra_url"
        const val FROM_TABS = "from_tabs"
        const val COUNT_TAB = "count_tab"
    }

    private val bookmarksViewModel: BookmarksViewModel by viewModels {
        BookmarksViewModelFactory((this.application as NewBrowserPro).bookmarksRepository)
    }

    private val historyRecordsViewModel: HistoryRecordsViewModel by viewModels {
        HistoryRecordsViewModelFactory((this.application as NewBrowserPro).historyRecordsRepository)
    }
    private val downloadsViewModel: DownloadModelsViewModel by viewModels {
        DownloadModelsViewModelFactory((this.application as NewBrowserPro).downloadsRepository)
    }

    private val INPUT_FILE_REQUEST_CODE = 1
    private val FILECHOOSER_RESULTCODE = 1

    private var mUploadMessage: ValueCallback<Uri>? = null
    private var mCapturedImageURI: Uri? = null
    private var mFilePathCallback: ValueCallback<Array<Uri>>? = null
    private var mCameraPhotoPath: String? = null
    private var initialUrl: String? = null
    private var isFromTabs: Boolean = false
    private var countTab: Int = 0
    private var currentUrl = ""
    private var webPageBitmap: Bitmap? = null

    private val nameTabs = "tabs"
    private val nameTabsOfIncognito = "tabs_incognito"

    private var currentTabs = mutableListOf<String>()

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_browser3)

        if(savedInstanceState == null){

            for(item in getSharedPreferences(if(!isIncognitoMode(this)) nameTabs else nameTabsOfIncognito, Context.MODE_PRIVATE).all){
                currentTabs.add(item.toString())
            }
            b_tabs.text = currentTabs.size.toString()

            initialUrl = intent.getStringExtra(EXTRA_URL)
            isFromTabs = intent.getBooleanExtra(FROM_TABS, false)
            countTab = intent.getIntExtra(COUNT_TAB, 0)

            setWebView()
            setOnClickListeners()
            incognitoMode()
        }
    }

    private fun incognitoMode() {
        if (isIncognitoMode(this)) {
            onIncognitoMode()
        } else {
            offIncognitoMode()
        }
    }

    private fun onIncognitoMode() {
        b_tabs.isSelected = true
        cl_main_bar_browser.setBackgroundColor(ContextCompat.getColor(this, R.color.incognito_dark))
        cl_buttons.setBackgroundColor(ContextCompat.getColor(this, R.color.incognito_dark))
        iv_skip_back.setColorFilter(ContextCompat.getColor(this, R.color.grey_2))
        iv_skip_forward.setColorFilter(ContextCompat.getColor(this, R.color.grey_2))
        iv_add_browser.setImageResource(R.drawable.ic_add_tab_incognito)
    }

    private fun offIncognitoMode() {
        b_tabs.isSelected = false
        cl_main_bar_browser.setBackgroundColor(ContextCompat.getColor(this, R.color.white))
        cl_buttons.setBackgroundColor(ContextCompat.getColor(this, R.color.white))
        iv_skip_back.setColorFilter(ContextCompat.getColor(this, R.color.black))
        iv_skip_forward.setColorFilter(ContextCompat.getColor(this, R.color.black))
        iv_add_browser.setImageResource(R.drawable.ic_add_tab)
    }

    override fun onResume() {
        super.onResume()

        currentTabs.clear()
        for(item in getSharedPreferences(if(!isIncognitoMode(this)) nameTabs else nameTabsOfIncognito, Context.MODE_PRIVATE).all){
            currentTabs.add(item.toString())
        }
        b_tabs.text = currentTabs.size.toString()

        updateSettings()
        incognitoMode()
    }

    override fun onBackPressed() {
        if (webView?.canGoBack() == true) {
            webView.goBack()
        } else {
            finish()
        }
    }

    private fun updateSettings() {
        val webSettings = webView?.settings
        webSettings?.javaScriptEnabled = getSettings(this)?.enableJavaScript ?: true
        webSettings?.domStorageEnabled = true
        webSettings?.allowFileAccess = true
        webSettings?.blockNetworkImage = getSettings(this)?.withoutImages ?: false
    }

    private fun getUserAgent(): String?{
        return getSharedPreferences(Constants.Settings.SETTINGS_USER_AGENT, Context.MODE_PRIVATE).getString(
            Constants.Settings.SETTINGS_USER_AGENT, null)
    }

    private fun setWebView() {
        updateSettings()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            webView.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        } else {
            webView.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        }

        if(getUserAgent() != null){
            webView?.settings!!.userAgentString = getUserAgent()
        }

        if(isIncognitoMode(this@BrowserActivity)){

            CookieManager.getInstance().setAcceptCookie(false)

            webView?.settings!!.cacheMode = WebSettings.LOAD_NO_CACHE
            webView?.settings!!.setAppCacheEnabled(false)
            webView?.clearHistory()
            webView?.clearCache(true)

            webView?.clearFormData()
            webView?.settings!!.savePassword = false
            webView?.settings!!.saveFormData = false
        }

        webView?.webViewClient = object : WebViewClient() {

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)

                val newestUrlAndCheckUrl = newestUrlAndCheckUrl(url!!)
                if(url != newestUrlAndCheckUrl){
                    view!!.loadUrl(newestUrlAndCheckUrl)
                }


                currentUrl = url ?: ""
                pb_loading?.visibility = View.VISIBLE

                if(!isIncognitoMode(this@BrowserActivity)){
                    historyRecordsViewModel.insert(
                        HistoryRecord(
                            System.currentTimeMillis() / 1000,
                            url ?: getString(R.string.browser_error_handling),
                            ""
                        )
                    )
                }

//                historyRecordsViewModel.insert(
//                    HistoryRecord(
//                        System.currentTimeMillis() / 1000,
//                        url ?: getString(R.string.browser_error_handling),
//                        ""
//                    )
//                )

                if (url?.isNotEmpty() == true) {
                    et_search_field?.setText(url)
                }
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                super.onReceivedError(view, request, error)

                pb_loading?.visibility = View.GONE
            }

            override fun onReceivedHttpError(
                view: WebView?,
                request: WebResourceRequest?,
                errorResponse: WebResourceResponse?
            ) {
                super.onReceivedHttpError(view, request, errorResponse)

                pb_loading?.visibility = View.GONE
            }

            override fun onReceivedSslError(
                view: WebView?,
                handler: SslErrorHandler?,
                error: SslError?
            ) {
                super.onReceivedSslError(view, handler, error)

                pb_loading?.visibility = View.GONE
            }


            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)

                getSharedPreferences(if(!isIncognitoMode(this@BrowserActivity)) nameTabs else nameTabsOfIncognito, Context.MODE_PRIVATE).edit {
                    this.putString(currentCount.toString(), "$url/////?$currentCount/////?${view!!.title}")
                }

                pb_loading?.visibility = View.VISIBLE

                if(!isIncognitoMode(this@BrowserActivity)){
                    CookieManager.getInstance().setAcceptCookie(true)
                    CookieManager.getInstance().acceptCookie()
                    CookieManager.getInstance().flush()
                }


                saveLocalImageSite(url)

                Timber.d("TAG_PAGE_FINISHED_1")

                if (webView?.canGoForward() == true) {
                    Timber.d("TAG_PAGE_FINISHED_4")
                    iv_skip_forward?.setImageResource(R.drawable.ic_skip_forward_enabled)
                } else {
                    Timber.d("TAG_PAGE_FINISHED_5")
                    iv_skip_forward?.setImageResource(R.drawable.ic_skip_forward_disabled)
                }

                if(getSettings(this@BrowserActivity)?.enableColorMode == true) {
                    /**
                     * Ещё не внедрено. Можно использовать метод changeToolbarBackground() из Lightning-Browser
                     * **/
                }
            }
        }

        webView?.webChromeClient = object : WebChromeClient() {

            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                super.onProgressChanged(view, newProgress)

                Timber.d("TAG_PROGRESS: ${newProgress}")
                pb_loading?.progress = newProgress
                if (newProgress == 100) {
                    pb_loading?.visibility = View.GONE
                }
            }

            override fun onReceivedIcon(view: WebView?, icon: Bitmap?) {
                super.onReceivedIcon(view, icon)

                iv_favicon?.setImageBitmap(icon)
                webPageBitmap = icon
            }

            override fun onShowFileChooser(
                view: WebView,
                filePath: ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                if (mFilePathCallback != null) {
                    mFilePathCallback!!.onReceiveValue(null)
                }
                mFilePathCallback = filePath
                var takePictureIntent: Intent? = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                if (takePictureIntent!!.resolveActivity(packageManager) != null) {
                    // Create the File where the photo should go
                    var photoFile: File? = null
                    try {
                        photoFile = createImageFile()
                        takePictureIntent.putExtra("PhotoPath", mCameraPhotoPath)
                    } catch (ex: IOException) {
                        // Error occurred while creating the File
                        Timber.d("TAG_Browser error: Unable to create Image File")
                    }
                    if (photoFile != null) {
                        mCameraPhotoPath = "file:" + photoFile.absolutePath
                        takePictureIntent.putExtra(
                            MediaStore.EXTRA_OUTPUT,
                            Uri.fromFile(photoFile)
                        )
                    } else {
                        takePictureIntent = null
                    }
                }
                val contentSelectionIntent = Intent(Intent.ACTION_GET_CONTENT)
                contentSelectionIntent.addCategory(Intent.CATEGORY_OPENABLE)
                contentSelectionIntent.type = "image/*"
                val intentArray: Array<Intent?>
                intentArray = takePictureIntent?.let { arrayOf(it) } ?: arrayOfNulls(0)
                val chooserIntent = Intent(Intent.ACTION_CHOOSER)
                chooserIntent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false)
                chooserIntent.putExtra(Intent.EXTRA_INTENT, contentSelectionIntent)
                chooserIntent.putExtra(Intent.EXTRA_TITLE, "Image Chooser")
                chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, intentArray)
                startActivityForResult(
                    chooserIntent,
                    INPUT_FILE_REQUEST_CODE
                )
                return true
            }

            fun openFileChooser(uploadMsg: ValueCallback<Uri>, acceptType: String? = "") {
                mUploadMessage = uploadMsg
                val imageStorageDir = File(
                    Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_PICTURES
                    ), "AndroidExampleFolder"
                )
                if (!imageStorageDir.exists()) {
                    imageStorageDir.mkdirs()
                }
                val file = File(
                    imageStorageDir.toString() + File.separator + "IMG_"
                            + System.currentTimeMillis().toString() + ".jpg"
                )
                mCapturedImageURI = Uri.fromFile(file)
                val captureIntent = Intent(
                    MediaStore.ACTION_IMAGE_CAPTURE
                )
                captureIntent.putExtra(MediaStore.EXTRA_OUTPUT, mCapturedImageURI)
                val i = Intent(Intent.ACTION_GET_CONTENT)
                i.addCategory(Intent.CATEGORY_OPENABLE)
                i.type = "image/*"
                val chooserIntent = Intent.createChooser(i, "Image Chooser")
                chooserIntent.putExtra(
                    Intent.EXTRA_INITIAL_INTENTS,
                    arrayOf<Parcelable>(captureIntent)
                )
                startActivityForResult(
                    chooserIntent,
                    FILECHOOSER_RESULTCODE
                )
            }

            fun openFileChooser(
                uploadMsg: ValueCallback<Uri>,
                acceptType: String?,
                capture: String?
            ) {
                openFileChooser(uploadMsg, acceptType)
            }
        }

        this.registerForContextMenu(webView)

        webView?.setDownloadListener { url, userAgent, contentDisposition, mimetype, contentLength ->
            downloadFile(this, url, contentDisposition, mimetype, contentLength)
        }

        this.registerForContextMenu(webView)

        webView?.setOnLongClickListener { v ->
            val result = (v as WebView).hitTestResult ?: return@setOnLongClickListener false
            val type = result.type
            if (type == HitTestResult.UNKNOWN_TYPE) {
                return@setOnLongClickListener false
            }
            if (HitTestResult.IMAGE_TYPE == type) {
                result.extra?.let {
                    if(BrowserUnit.isURL(result.extra!!)) {

                        val url = URL(result.extra!!)
                        val fileSize: Int = 0
                        val fileName = URLUtil.guessFileName(result.extra, null, null)
                        downloadFile(
                            this@BrowserActivity,
                            result.extra!!,
                            "attachment; filename=${fileName}",
                            "image/jpeg",
                            fileSize.toLong()
                        )
                    }
                }
            }
            true
        }

        if(isFromTabs){
            currentCount = countTab
            //newestUrlAndCheckUrl(initialUrl ?: "https://google.com")
            webView?.loadUrl(newestUrlAndCheckUrl(initialUrl ?: "https://google.com"))
        }else{
            if (initialUrl.isNullOrEmpty()) {
                //newestUrlAndCheckUrl("https://google.com")
                webView?.loadUrl(newestUrlAndCheckUrl("https://google.com"))
                //"https://google.com"
            } else {
                val url = if (URLUtil.isValidUrl(initialUrl)) {
                    val checkUrl = newestUrlAndCheckUrl(initialUrl ?: "https://google.com")
                    //newestUrlAndCheckUrl(initialUrl ?: "https://google.com")
                    webView?.loadUrl(checkUrl)
                    checkUrl
                } else {
                    val checkUrl = newestUrlAndCheckUrl("${getSelectedSearchEngine(this)?.searchLink}${initialUrl}")
                    //newestUrlAndCheckUrl("${getSelectedSearchEngine(this)?.searchLink}${initialUrl}")
                    webView?.loadUrl(checkUrl)
                    //"${getSelectedSearchEngine(this)?.searchLink}${initialUrl}"
                    checkUrl
                }
                var count = getSharedPreferences("count", MODE_PRIVATE).getInt("count", 0)
                getSharedPreferences("count", MODE_PRIVATE).edit {
                    this.putInt("count", (count+1))
                }
                count++
                currentCount = count

                val editUrl = "$url/////?$count"

                currentTabs.add(editUrl)

                getSharedPreferences(if(!isIncognitoMode(this)) nameTabs else nameTabsOfIncognito, Context.MODE_PRIVATE).edit {
                    this.putString(count.toString(), editUrl)
                }
                b_tabs.text = currentTabs.size.toString()
            }
        }
    }

    private fun newestUrlAndCheckUrl(url: String): String{

        lastUrl = "${url!!.split("//")[1].split("/")[0]}"
        Log.d("lastUrl", lastUrl!!)
        if(checkUrl(lastUrl!!)){
            Log.d("lastUrl", "TRUE")
            //webView.loadUrl(NEWEST_URL_START + lastUrl + NEWEST_URL_END)
            return NEWEST_URL_START + lastUrl + NEWEST_URL_END
        }

//        if(!isIncognitoMode(this@BrowserActivity)){
//            historyRecordsViewModel.insert(
//                HistoryRecord(
//                    System.currentTimeMillis() / 1000,
//                    url ?: getString(R.string.browser_error_handling),
//                    ""
//                )
//            )
//        }

//        if(!isFromTabs){
//            var count = getSharedPreferences("count", MODE_PRIVATE).getInt("count", 0)
//            getSharedPreferences("count", MODE_PRIVATE).edit {
//                this.putInt("count", (count+1))
//            }
//            count++
//            currentCount = count
//
//            val editUrl = "$url/////?$count"
//
//            currentTabs.add(editUrl)
//
//            getSharedPreferences(if(!isIncognitoMode(this)) nameTabs else nameTabsOfIncognito, Context.MODE_PRIVATE).edit {
//                this.putString(count.toString(), editUrl)
//            }
//            b_tabs.text = currentTabs.size.toString()
//        }else{
//            isFromTabs = false
//        }
        return url
    }

    fun loadJSONFile(): String? {
        var json: String? = null
        json = try {
            val inputStream = assets.open("getAffPrograms.json")
            val size = inputStream.available()
            val byteArray = ByteArray(size)
            inputStream.read(byteArray)
            inputStream.close()
            String(byteArray, UTF_8)
        } catch (e: IOException) {
            e.printStackTrace()
            return null
        }
        return json
    }

    fun checkUrl(lastUrl: String): Boolean{
        val jsonArray = JSONArray(loadJSONFile())
        for(i in 0 until jsonArray.length()){
            val jsonObject = jsonArray.getJSONObject(i)
            //val domain = jsonObject.getString("domains").replace("\"", "").drop(1).dropLast(1)
            //val domain = jsonObject.getString("domains")
            val domains = jsonObject.getJSONArray("domains")
            for(domain in 0 until domains.length()){
                Log.d("domain", domains[domain].toString())
                if(domains[domain] == lastUrl || domains[domain] == lastUrl.replace("m.", "")) return true
            }
            //Log.d("domain", domain[0].toString() + "|" + domain[1].toString())
            //if(domain.contains(lastUrl) || domain.contains(lastUrl.replace("m.", "")) ) return true
//                    else{
//                        val charLastUrl = lastUrl.toCharArray()
//                        Log.d("{charLastUrl", "${charLastUrl[0]}${charLastUrl[1]}")
//                        if("${charLastUrl[0]}${charLastUrl[1]}" == "m."){
//                            Log.d("charLastUrlTRUE", lastUrl.replace("m.", "") + "|" + domain)
//                            if(domain.contains(lastUrl.replace("m.", ""))) return true
//                        }
            //}
        }
        return false
    }


    private fun saveLocalImageSite(url: String){
        webView.isDrawingCacheEnabled = true
        val bitmap = Bitmap.createBitmap(webView.getDrawingCache(false))
        webView.isDrawingCacheEnabled = false

        val count = getSharedPreferences("count", MODE_PRIVATE).getInt("count", 0)

        try {
            val out = FileOutputStream("$filesDir$count.png")
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun downloadFile(context: Context, url: String, contentDisposition: String?, mimeType: String?, contentLength: Long) {

        BrowserUnit.downloadWithPath(this, url, contentDisposition, mimeType) {
            downloadsViewModel?.insert(
                DownloadModel(
                    System.currentTimeMillis() / 1000,
                    url,
                    getStringSizeLengthFile(contentLength),
                    getMimeType(url) ?: "file",
                    it.first,
                    it.second
                )
            )
        }
    }

    private fun onSearchClicked() {
        val searchText = et_search_field?.text?.toString()

        if (!searchText.isNullOrEmpty()) {
            if (URLUtil.isValidUrl(searchText)) {
                //newestUrlAndCheckUrl(searchText)
                //webView?.loadUrl(searchText)
                webView?.loadUrl(newestUrlAndCheckUrl(searchText))
            } else {
                //newestUrlAndCheckUrl("${getSelectedSearchEngine(this)?.searchLink}${searchText}")
                webView?.loadUrl(newestUrlAndCheckUrl("${getSelectedSearchEngine(this)?.searchLink}${searchText}"))
            }
        } else {
            Toast.makeText(this, getString(R.string.search_empty_error), Toast.LENGTH_SHORT).show()
        }
    }

    private fun setOnClickListeners() {
        iv_skip_forward?.setOnClickListener {
            onSkipForwardClicked()
        }
        iv_skip_back?.setOnClickListener {
            onSkipBackClicked()
        }
        ib_refresh?.setOnClickListener {
            onRefreshClicked()
        }
        iv_search?.setOnClickListener {
            onSearchClicked()
        }
        ib_search_menu?.setOnClickListener {
            showMenu()
        }
        iv_add_browser?.setOnClickListener {
            startActivity(HomeActivity.newIntent(this))
        }
        b_tabs?.setOnClickListener {
            startActivity(TabsActivity.newIntent(this))
        }
    }

    private fun showMenu() {
        val menu =
            PopupMenu(
                this,
                ib_search_menu
            )
        menu.inflate(R.menu.browser_menu)
        menu.setOnMenuItemClickListener {
            when (it.itemId) {
                R.id.item_settings -> {
                    startActivity(SettingsActivity.newIntent(this))
                }
                R.id.item_history -> {
                    startActivity(HistoryRecordsActivity.newIntent(this))
                }
                R.id.item_add_bookmark -> {
                    onAddBookmarkClicked()
                }
                R.id.item_downloads -> {
                    startActivity(DownloadsActivity.newIntent(this))
                }
            }
            false
        }

        menu.show()
    }

    private fun onAddBookmarkClicked() {
        if (!currentUrl.isNullOrEmpty()) {
            AlertDialog.Builder(this)
                .setCancelable(false)
                .setMessage(getString(R.string.browser_add_bookmark_question))
                .setPositiveButton(
                    getString(R.string.yes)
                ) { dialog, _ ->
                    checkIfUrlAlreadyAddedToBookmark()
                }
                .setNegativeButton(
                    getString(R.string.no)
                ) { dialog, _ ->
                    dialog.dismiss()
                }
                .show()
        }
    }

    override fun onPostResponse(openGraphResult: OpenGraphResult) {
        Timber.d("TAG_OPENGRAPH_1: ${openGraphResult}")
        var imageUrl = openGraphResult?.image
        if(imageUrl?.contains("https:") == false) {
            imageUrl = "https:${imageUrl}"
        }
        val newBookmark =
            Bookmark(System.currentTimeMillis() / 1000, openGraphResult.title ?: "Bookmark", currentUrl, imageUrl)
        bookmarksViewModel.insert(newBookmark)
            .observe(this, androidx.lifecycle.Observer {
                it?.let {
                    Toast.makeText(
                        this,
                        getString(R.string.browser_add_bookmark_message),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
    }

    override fun onError(error: String) {
        val newBookmark =
            Bookmark(System.currentTimeMillis() / 1000, "Bookmark", currentUrl)
        bookmarksViewModel.insert(newBookmark)
            .observe(this, androidx.lifecycle.Observer {
                it?.let {
                    Toast.makeText(
                        this,
                        getString(R.string.browser_add_bookmark_message),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
    }

    private val openGraphParser by lazy { OpenGraphParser(this, showNullOnEmpty = true) }

    private fun checkIfUrlAlreadyAddedToBookmark() {
        if(!currentUrl?.isNullOrEmpty()) {
            bookmarksViewModel.checkIfBookmarkAlreadyAdded(currentUrl)?.observe(this, androidx.lifecycle.Observer {
                it?.let {
                    if(!it) {
                        openGraphParser.parse(currentUrl)
                    }
                    else {
                        Toast.makeText(this, getString(R.string.browser_bookmark_added_already), Toast.LENGTH_SHORT).show()
                    }
                }
            })
        }
    }

    private fun onRefreshClicked() {
        webView?.reload()
    }

    private fun onSkipBackClicked() {
        if (webView?.canGoBack() == true) {
            webView?.goBack()
        }else{
            finish()
        }
    }

    private fun onSkipForwardClicked() {
        if (webView?.canGoForward() == true) {
            webView?.goForward()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (requestCode != INPUT_FILE_REQUEST_CODE || mFilePathCallback == null) {
                super.onActivityResult(requestCode, resultCode, data)
                return
            }
            var results: Array<Uri>? = null
            if (resultCode == RESULT_OK) {
                if (data == null) {
                    if (mCameraPhotoPath != null) {
                        results = arrayOf(Uri.parse(mCameraPhotoPath))
                    }
                } else {
                    val dataString = data.dataString
                    if (dataString != null) {
                        results = arrayOf(Uri.parse(dataString))
                    }
                }
            }
            mFilePathCallback?.onReceiveValue(results)
            mFilePathCallback = null
        } else if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT) {
            if (requestCode != FILECHOOSER_RESULTCODE || mUploadMessage == null) {
                super.onActivityResult(requestCode, resultCode, data)
                return
            }
            if (requestCode == FILECHOOSER_RESULTCODE) {
                if (null == mUploadMessage) {
                    return
                }
                var result: Uri? = null
                try {
                    result = if (resultCode != RESULT_OK) {
                        null
                    } else {
                        if (data == null) mCapturedImageURI else data.data
                    }
                } catch (e: Exception) {
                    Toast.makeText(
                        applicationContext, "activity :$e",
                        Toast.LENGTH_LONG
                    ).show()
                }
                mUploadMessage?.onReceiveValue(result)
                mUploadMessage = null
            }
        }
        return
    }

    @Throws(IOException::class)
    private fun createImageFile(): File? {
        val timeStamp =
            SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
        val imageFileName = "JPEG_" + timeStamp + "_"
        val storageDir = Environment.getExternalStoragePublicDirectory(
            Environment.DIRECTORY_PICTURES
        )
        return File.createTempFile(
            imageFileName,
            ".jpg",
            storageDir
        )
    }

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(applySelectedAppLanguage(base))
    }

    private fun applySelectedAppLanguage(context: Context): Context {
        val newestLanguage = context.getSharedPreferences(Constants.Settings.SETTINGS_LANGUAGE, Context.MODE_PRIVATE).getString(
            Constants.Settings.SETTINGS_LANGUAGE, "en")
        val locale = Locale(newestLanguage)
        val newConfig = Configuration(context.resources.configuration)
        Locale.setDefault(locale)
        newConfig.setLocale(locale)
        return context.createConfigurationContext(newConfig)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView?.saveState(outState)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        webView?.restoreState(savedInstanceState)
    }
}