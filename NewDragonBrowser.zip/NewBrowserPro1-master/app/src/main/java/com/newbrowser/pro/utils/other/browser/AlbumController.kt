package com.newbrowser.pro.utils.other.browser

import android.view.View

interface AlbumController {
    val albumView: View?
    fun activate()
    fun deactivate()
}
